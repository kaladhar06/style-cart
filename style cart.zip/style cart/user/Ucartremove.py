def remove_from_cart(cart):

    if not cart:
        print("\nYour cart is empty.")
        return

    print("\n===== Remove Product from Cart =====")

    try:
        product_id = int(input("Enter Product ID to remove: "))
    except ValueError:
        print("\nPlease enter a valid Product ID.")
        return

    for item in cart:

        if item["id"] == product_id:

            cart.remove(item)

            print("\nProduct removed from cart successfully.")
            return

    print("\nProduct not found in your cart.")