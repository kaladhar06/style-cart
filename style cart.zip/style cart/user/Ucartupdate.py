def update_cart(cart):

    if not cart:
        print("\nYour cart is empty.")
        return

    print("\n===== Update Cart Quantity =====")

    try:
        product_id = int(input("Enter Product ID: "))
    except ValueError:
        print("\nPlease enter a valid Product ID.")
        return

    for item in cart:

        if item["id"] == product_id:

            print(f"\nProduct: {item['name']}")
            print(f"Current Quantity: {item['quantity']}")

            try:
                new_quantity = int(input("Enter new quantity: "))
            except ValueError:
                print("\nPlease enter a valid quantity.")
                return

            if new_quantity <= 0:
                print("\nQuantity must be greater than 0.")
                return

            item["quantity"] = new_quantity

            print("\nCart updated successfully!")
            return

    print("\nProduct not found in your cart.")