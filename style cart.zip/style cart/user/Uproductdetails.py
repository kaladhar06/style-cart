import json
import os


PRODUCT_FILE = "../data/products.json"


def load_products():
    if not os.path.exists(PRODUCT_FILE):
        return []

    with open(PRODUCT_FILE, "r") as file:
        return json.load(file)


def product_details():

    products = load_products()

    if not products:
        print("\nNo products available.")
        return

    print("\n===== Product Details =====")

    try:
        product_id = int(input("Enter Product ID: "))
    except ValueError:
        print("\nPlease enter a valid Product ID.")
        return

    for product in products:

        if product["id"] == product_id:

            print("\n===== Product Information =====")
            print(f"Product ID : {product['id']}")
            print(f"Product    : {product['name']}")
            print(f"Category   : {product['category']}")
            print(f"Price      : ₹{product['price']:.2f}")
            print(f"Size       : {product['size']}")
            print(f"Stock      : {product['quantity']}")

            return

    print("\nProduct ID not found.")