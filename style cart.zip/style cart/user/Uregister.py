import json
import os


USER_FILE = "../data/users.json"


def load_users():
    if not os.path.exists(USER_FILE):
        return []

    with open(USER_FILE, "r") as file:
        return json.load(file)


def save_users(users):
    with open(USER_FILE, "w") as file:
        json.dump(users, file, indent=4)


def register_user():

    users = load_users()

    print("\n===== StyleCart User Registration =====")

    name = input("Enter your name: ")
    username = input("Enter username: ")

    for user in users:

        if user["username"] == username:
            print("\nUsername already exists.")
            return

    password = input("Enter password: ")

    if users:
        user_id = users[-1]["user_id"] + 1
    else:
        user_id = 1001

    user = {
        "user_id": user_id,
        "name": name,
        "username": username,
        "password": password
    }

    users.append(user)

    save_users(users)

    print("\nRegistration successful!")
    print(f"Your User ID is: {user_id}")