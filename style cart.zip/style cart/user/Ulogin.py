import json
import os


USER_FILE = "../data/users.json"


def load_users():
    if not os.path.exists(USER_FILE):
        return []

    with open(USER_FILE, "r") as file:
        return json.load(file)


def user_login():

    users = load_users()

    print("\n===== StyleCart User Login =====")

    username = input("Enter username: ")
    password = input("Enter password: ")

    for user in users:

        if user["username"] == username and user["password"] == password:

            print("\nLogin successful!")
            print(f"Welcome, {user['name']}!")

            return user

    print("\nInvalid username or password.")
    return None