import json
import os


PRODUCT_FILE = "../data/products.json"
ORDER_FILE = "../data/orders.json"


def load_products():
    if not os.path.exists(PRODUCT_FILE):
        return []

    with open(PRODUCT_FILE, "r") as file:
        return json.load(file)


def save_products(products):
    with open(PRODUCT_FILE, "w") as file:
        json.dump(products, file, indent=4)


def load_orders():
    if not os.path.exists(ORDER_FILE):
        return []

    with open(ORDER_FILE, "r") as file:
        return json.load(file)


def save_orders(orders):
    with open(ORDER_FILE, "w") as file:
        json.dump(orders, file, indent=4)


def checkout(user, cart):

    if not cart:
        print("\nYour cart is empty.")
        return

    products = load_products()
    orders = load_orders()

    print("\n===== StyleCart Checkout =====")

    total = 0

    for item in cart:

        item_total = item["price"] * item["quantity"]
        total += item_total

        print("\nProduct :", item["name"])
        print("Price   : ₹{:.2f}".format(item["price"]))
        print("Quantity:", item["quantity"])
        print("Total   : ₹{:.2f}".format(item_total))

    print("\n------------------------------")
    print("Cart Total: ₹{:.2f}".format(total))
    print("------------------------------")

    confirmation = input("\nConfirm Order? (yes/no): ").lower()

    if confirmation != "yes":
        print("\nOrder cancelled.")
        return

    # Check stock before placing order
    for item in cart:

        for product in products:

            if product["id"] == item["id"]:

                if item["quantity"] > product["quantity"]:
                    print(
                        f"\nSorry! Only {product['quantity']} "
                        f"items of {product['name']} are available."
                    )
                    return

    # Generate Order ID
    if orders:
        order_id = orders[-1]["order_id"] + 1
    else:
        order_id = 5001

    # Create order
    for item in cart:

        order = {
            "order_id": order_id,
            "user_id": user["user_id"],
            "customer": user["name"],
            "product": item["name"],
            "product_id": item["id"],
            "quantity": item["quantity"],
            "price": item["price"],
            "total": item["price"] * item["quantity"],
            "status": "Pending"
        }

        orders.append(order)

        # Reduce product stock
        for product in products:

            if product["id"] == item["id"]:
                product["quantity"] -= item["quantity"]

        order_id += 1

    save_orders(orders)
    save_products(products)

    cart.clear()

    print("\n================================")
    print("       Order Placed Successfully!")
    print("================================")

    print(f"Customer : {user['name']}")
    print(f"Total    : ₹{total:.2f}")

    print("\nThank you for shopping with StyleCart!")