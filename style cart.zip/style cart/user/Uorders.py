import json
import os


ORDER_FILE = "../data/orders.json"


def load_orders():
    if not os.path.exists(ORDER_FILE):
        return []

    with open(ORDER_FILE, "r") as file:
        return json.load(file)


def view_my_orders(user):

    orders = load_orders()

    print("\n===== My Orders =====")

    my_orders = []

    for order in orders:

        if order["user_id"] == user["user_id"]:
            my_orders.append(order)

    if not my_orders:
        print("You have not placed any orders yet.")
        return

    for order in my_orders:

        print("\n" + "-" * 50)

        print(f"Order ID : {order['order_id']}")
        print(f"Product  : {order['product']}")
        print(f"Quantity : {order['quantity']}")
        print(f"Price    : ₹{order['price']:.2f}")
        print(f"Total    : ₹{order['total']:.2f}")
        print(f"Status   : {order['status']}")

    print("-" * 50)