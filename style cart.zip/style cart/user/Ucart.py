import json
import os


PRODUCT_FILE = "../data/products.json"


def load_products():
    if not os.path.exists(PRODUCT_FILE):
        return []

    with open(PRODUCT_FILE, "r") as file:
        return json.load(file)


def add_to_cart(cart):

    products = load_products()

    if not products:
        print("\nNo products available.")
        return

    print("\n===== Add Product to Cart =====")

    try:
        product_id = int(input("Enter Product ID: "))
    except ValueError:
        print("\nPlease enter a valid Product ID.")
        return

    for product in products:

        if product["id"] == product_id:

            if product["quantity"] <= 0:
                print("\nSorry, this product is out of stock.")
                return

            try:
                quantity = int(input("Enter quantity: "))
            except ValueError:
                print("\nPlease enter a valid quantity.")
                return

            if quantity <= 0:
                print("\nQuantity must be greater than 0.")
                return

            if quantity > product["quantity"]:
                print(
                    f"\nOnly {product['quantity']} items are available."
                )
                return

            cart.append({
                "id": product["id"],
                "name": product["name"],
                "category": product["category"],
                "price": product["price"],
                "size": product["size"],
                "quantity": quantity
            })

            print("\nProduct added to cart successfully!")
            return

    print("\nProduct ID not found.")


def view_cart(cart):

    print("\n===== My Cart =====")

    if not cart:
        print("Your cart is empty.")
        return

    total = 0

    print("-" * 75)
    print(
        f"{'ID':<6}"
        f"{'Product':<25}"
        f"{'Price':<12}"
        f"{'Qty':<8}"
        f"{'Total':<12}"
    )
    print("-" * 75)

    for item in cart:

        item_total = item["price"] * item["quantity"]
        total += item_total

        print(
            f"{item['id']:<6}"
            f"{item['name']:<25}"
            f"₹{item['price']:<11.2f}"
            f"{item['quantity']:<8}"
            f"₹{item_total:<11.2f}"
        )

    print("-" * 75)
    print(f"Cart Total: ₹{total:.2f}")