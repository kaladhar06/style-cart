import json
import os


PRODUCT_FILE = "../data/products.json"


def load_products():
    if not os.path.exists(PRODUCT_FILE):
        return []

    with open(PRODUCT_FILE, "r") as file:
        return json.load(file)


def view_men_products():
    products = load_products()

    print("\n===== Men's Clothing =====")

    men_products = []

    for product in products:
        if product["category"] == "Men":
            men_products.append(product)

    if not men_products:
        print("No men's clothing available.")
        return

    print("-" * 70)
    print(f"{'ID':<6}{'Product':<25}{'Price':<15}{'Size':<10}{'Stock':<10}")
    print("-" * 70)

    for product in men_products:
        print(
            f"{product['id']:<6}"
            f"{product['name']:<25}"
            f"₹{product['price']:<14.2f}"
            f"{product['size']:<10}"
            f"{product['quantity']:<10}"
        )

    print("-" * 70)


def view_women_products():
    products = load_products()

    print("\n===== Women's Clothing =====")

    women_products = []

    for product in products:
        if product["category"] == "Women":
            women_products.append(product)

    if not women_products:
        print("No women's clothing available.")
        return

    print("-" * 70)
    print(f"{'ID':<6}{'Product':<25}{'Price':<15}{'Size':<10}{'Stock':<10}")
    print("-" * 70)

    for product in women_products:
        print(
            f"{product['id']:<6}"
            f"{product['name']:<25}"
            f"₹{product['price']:<14.2f}"
            f"{product['size']:<10}"
            f"{product['quantity']:<10}"
        )

    print("-" * 70)