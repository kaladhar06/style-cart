from Uregister import register_user
from Ulogin import user_login
from Uviewproduct import view_men_products, view_women_products
from Uproductdetails import product_details
from Ucart import add_to_cart, view_cart
from Ucartremove import remove_from_cart
from Ucartupdate import update_cart
from Ucheckout import checkout
from Uorders import view_my_orders


def user_dashboard(user):

    cart = []

    while True:

        print("\n===== StyleCart =====")
        print(f"Welcome, {user['name']}!")

        print("\n1. Men's Clothing")
        print("2. Women's Clothing")
        print("3. Product Details")
        print("4. Add to Cart")
        print("5. View Cart")
        print("6. Remove from Cart")
        print("7. Update Cart")
        print("8. Checkout")
        print("9. My Orders")
        print("10. Logout")

        choice = input("\nEnter your choice: ")

        if choice == "1":
            view_men_products()

        elif choice == "2":
            view_women_products()

        elif choice == "3":
            product_details()

        elif choice == "4":
            add_to_cart(cart)

        elif choice == "5":
            view_cart(cart)

        elif choice == "6":
            remove_from_cart(cart)

        elif choice == "7":
            update_cart(cart)

        elif choice == "8":
            checkout(user, cart)

        elif choice == "9":
            view_my_orders(user)

        elif choice == "10":
            print("\nLogged out successfully.")
            break

        else:
            print("\nInvalid choice. Please try again.")


def main():

    print("================================")
    print("       Welcome to StyleCart")
    print("          User Panel")
    print("================================")

    while True:

        print("\n1. Register")
        print("2. Login")
        print("3. Exit")

        choice = input("\nEnter your choice: ")

        if choice == "1":
            register_user()

        elif choice == "2":
            user = user_login()

            if user:
                user_dashboard(user)

        elif choice == "3":
            print("\nThank you for using StyleCart.")
            break

        else:
            print("\nInvalid choice. Please try again.")


if __name__ == "__main__":
    main()