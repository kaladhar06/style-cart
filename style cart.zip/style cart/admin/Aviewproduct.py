import json
import os


PRODUCT_FILE = "../data/products.json"


def load_products():
    if not os.path.exists(PRODUCT_FILE):
        return []

    with open(PRODUCT_FILE, "r") as file:
        return json.load(file)


def view_products():
    products = load_products()

    print("\n===== StyleCart Products =====")

    if not products:
        print("No products available.")
        return

    print("-" * 85)
    print(
        f"{'ID':<6}"
        f"{'Product':<25}"
        f"{'Category':<12}"
        f"{'Price':<12}"
        f"{'Size':<10}"
        f"{'Stock':<10}"
    )
    print("-" * 85)

    for product in products:
        print(
            f"{product['id']:<6}"
            f"{product['name']:<25}"
            f"{product['category']:<12}"
            f"₹{product['price']:<11.2f}"
            f"{product['size']:<10}"
            f"{product['quantity']:<10}"
        )

    print("-" * 85)