import json
import os


ORDER_FILE = "../data/orders.json"


def load_orders():
    if not os.path.exists(ORDER_FILE):
        return []

    with open(ORDER_FILE, "r") as file:
        return json.load(file)


def save_orders(orders):
    with open(ORDER_FILE, "w") as file:
        json.dump(orders, file, indent=4)


def view_orders():
    orders = load_orders()

    print("\n===== StyleCart Orders =====")

    if not orders:
        print("No orders available.")
        return

    for order in orders:

        print("\n" + "-" * 45)

        print(f"Order ID   : {order['order_id']}")
        print(f"Customer   : {order['customer']}")
        print(f"Product    : {order['product']}")
        print(f"Quantity   : {order['quantity']}")
        print(f"Total      : ₹{order['total']}")
        print(f"Status     : {order['status']}")

    print("-" * 45)