from Aloginpage import admin_login
from Aaddproduct import add_product
from Aviewproduct import view_products
from Aupdateproduct import update_product
from Adeleteproduct import delete_product
from Aorders import view_orders


def admin_menu():

    while True:

        print("\n===== StyleCart Admin Panel =====")
        print("1. Add Product")
        print("2. View Products")
        print("3. Update Product")
        print("4. Delete Product")
        print("5. View Orders")
        print("6. Exit")

        choice = input("Enter your choice: ")

        if choice == "1":
            add_product()

        elif choice == "2":
            view_products()

        elif choice == "3":
            update_product()

        elif choice == "4":
            delete_product()

        elif choice == "5":
            view_orders()

        elif choice == "6":
            print("\nThank you for using StyleCart Admin Panel.")
            break

        else:
            print("\nInvalid choice. Please try again.")


def main():

    print("================================")
    print("       Welcome to StyleCart")
    print("          Admin Panel")
    print("================================")

    login_success = admin_login()

    if login_success:
        admin_menu()


if __name__ == "__main__":
    main()