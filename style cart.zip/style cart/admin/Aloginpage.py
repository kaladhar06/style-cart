import json
def admin_login():
    with open("../data/admin.json", "r") as file:
        admin = json.load(file)
    print("\n StyleCart Admin Login ")
    username = input("Enter username: ")
    password = input("Enter password: ")
    if username == admin["username"] and password == admin["password"]:
        print("\nLogin successful!")
        print(f"Welcome, {username}!")
        return True
    print("\nInvalid username or password.")
    return False