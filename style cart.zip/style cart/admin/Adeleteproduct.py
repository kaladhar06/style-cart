import json
import os


PRODUCT_FILE = "../data/products.json"


def load_products():
    if not os.path.exists(PRODUCT_FILE):
        return []

    with open(PRODUCT_FILE, "r") as file:
        return json.load(file)


def save_products(products):
    with open(PRODUCT_FILE, "w") as file:
        json.dump(products, file, indent=4)


def delete_product():
    products = load_products()

    if not products:
        print("\nNo products available.")
        return

    print("\n===== Delete Product =====")

    product_id = int(input("Enter Product ID: "))

    for product in products:

        if product["id"] == product_id:

            print("\nProduct Found!")
            print(f"Product Name: {product['name']}")
            print(f"Category: {product['category']}")
            print(f"Price: ₹{product['price']}")
            print(f"Size: {product['size']}")
            print(f"Stock: {product['quantity']}")

            confirmation = input(
                "\nAre you sure you want to delete this product? (yes/no): "
            ).lower()

            if confirmation == "yes":

                products.remove(product)
                save_products(products)

                print("\nProduct deleted successfully.")
                return

            else:
                print("\nProduct deletion cancelled.")
                return

    print("\nProduct ID not found.")