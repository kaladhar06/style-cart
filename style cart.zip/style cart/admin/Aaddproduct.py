import json
import os


PRODUCT_FILE = "../data/products.json"


def load_products():
    if not os.path.exists(PRODUCT_FILE):
        return []

    with open(PRODUCT_FILE, "r") as file:
        return json.load(file)


def save_products(products):
    with open(PRODUCT_FILE, "w") as file:
        json.dump(products, file, indent=4)


def add_product():
    products = load_products()

    print("\n===== Add New Product =====")

    name = input("Enter product name: ")

    while True:
        category = input("Enter category (Men/Women): ").strip().capitalize()

        if category in ["Men", "Women"]:
            break

        print("Please enter only Men or Women.")

    price = float(input("Enter price: "))
    size = input("Enter size: ").upper()
    quantity = int(input("Enter quantity: "))

    if products:
        product_id = products[-1]["id"] + 1
    else:
        product_id = 101

    product = {
        "id": product_id,
        "name": name,
        "category": category,
        "price": price,
        "size": size,
        "quantity": quantity
    }

    products.append(product)
    save_products(products)

    print("\nProduct added successfully!")
    print(f"Product ID: {product_id}")