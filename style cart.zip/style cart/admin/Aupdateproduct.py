import json
import os


PRODUCT_FILE = "../data/products.json"


def load_products():
    if not os.path.exists(PRODUCT_FILE):
        return []

    with open(PRODUCT_FILE, "r") as file:
        return json.load(file)


def save_products(products):
    with open(PRODUCT_FILE, "w") as file:
        json.dump(products, file, indent=4)


def update_product():
    products = load_products()

    if not products:
        print("\nNo products available.")
        return

    print("\n===== Update Product =====")

    product_id = int(input("Enter Product ID: "))

    for product in products:

        if product["id"] == product_id:

            print("\nProduct Found!")
            print(f"Product Name: {product['name']}")
            print(f"Category: {product['category']}")
            print(f"Price: ₹{product['price']}")
            print(f"Size: {product['size']}")
            print(f"Stock: {product['quantity']}")

            print("\nWhat do you want to update?")
            print("1. Product Name")
            print("2. Price")
            print("3. Size")
            print("4. Stock")

            choice = input("Enter your choice: ")

            if choice == "1":
                product["name"] = input("Enter new product name: ")
                print("\nProduct name updated successfully.")

            elif choice == "2":
                product["price"] = float(input("Enter new price: "))
                print("\nPrice updated successfully.")

            elif choice == "3":
                product["size"] = input("Enter new size: ").upper()
                print("\nSize updated successfully.")

            elif choice == "4":
                product["quantity"] = int(input("Enter new stock quantity: "))
                print("\nStock updated successfully.")

            else:
                print("\nInvalid choice.")
                return

            save_products(products)
            return

    print("\nProduct ID not found.")